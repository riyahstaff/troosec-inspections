# Troosec Inspections - Design Guidelines

## Design Approach
**Reference-Based Approach** drawing inspiration from premium service websites (Airbnb's trust-building, Apple's clean professionalism, and real estate platforms' visual storytelling). This creates a trustworthy, modern presence that educates while converting.

## Core Design Elements

### Color Palette
**Primary Colors:**
- Dark: 220 15% 15% (Professional navy-charcoal for headers, text)
- Brand Accent: 210 85% 45% (Confident blue for CTAs, trust signals)
- Light: 0 0% 98% (Clean white background)

**Supporting Colors:**
- Success Green: 145 65% 45% (Report delivery, checkmarks)
- Warm Gray: 25 8% 55% (Body text, supporting content)
- Light Blue Background: 210 40% 96% (Section alternation)

### Typography
- Headings: Inter or DM Sans (700, 600 weights) - modern, professional
- Body: Inter (400, 500 weights)
- Sizes: Hero h1 (text-5xl lg:text-7xl), Section h2 (text-3xl lg:text-5xl), Cards h3 (text-xl lg:text-2xl)

### Layout System
Tailwind spacing primitives: **2, 4, 6, 8, 12, 16, 20, 24**
- Section padding: py-16 lg:py-24
- Card spacing: p-6 lg:p-8
- Grid gaps: gap-6 lg:gap-8

## Page Structure

### Hero Section (Full-width, 85vh)
- Large background image: Professional inspector examining property detail
- Centered overlay content with blurred background for buttons
- Headline: "Professional Home Inspections You Can Trust"
- Subheadline: "Comprehensive 24-Hour Reports • Licensed & Certified • Serving [Area]"
- Dual CTAs: Primary "Schedule Inspection", Secondary outline "View Sample Report"
- Trust badges below: Years in business, inspections completed, certification logos

### Services Overview (3-column grid)
Cards with icons, titles, descriptions:
- Pre-Purchase Inspections
- Pre-Listing Inspections  
- New Construction Inspections
Each card includes image thumbnail, bullet points of what's covered

### Education Section - "What to Expect"
Timeline-style layout showing inspection process:
1. Schedule & Preparation
2. On-Site Inspection (3-4 hours)
3. Detailed Report Delivery (24 hours)
4. Follow-up Consultation

Include embedded video placeholder showing inspection walkthrough

### Why Choose Troosec (2-column split)
Left: List of differentiators with checkmarks
Right: Image of inspector with equipment/technology

### Report Showcase
Visual representation of sample report with callouts:
- 200+ inspection points
- High-resolution photos
- Detailed descriptions
- Priority ratings
- Maintenance recommendations
Emphasize 24-hour delivery guarantee prominently

### Gallery Section
Masonry grid (3-4 columns) of inspection photos showing:
- Various property types
- Different inspection scenarios
- Technology/equipment in use
- Before/after examples

### Testimonials (2-3 column cards)
Client photos, quotes, property type inspected, date

### FAQ Accordion
Common questions about home inspections, process, pricing

### Final CTA Section
Bold, centered with background image
"Ready for Peace of Mind?" + scheduling button
Include phone number, email prominently

### Footer
Rich footer with:
- Quick links (Services, About, Contact, Resources)
- Service areas
- Contact information with office hours
- Social media links
- Certifications/affiliations
- Newsletter signup for home maintenance tips

## Component Library

**Buttons:**
- Primary: Solid brand blue, white text, rounded-lg, px-8 py-4
- Secondary: Outline white (on images), blurred background
- Hover: Slight scale, deeper color

**Cards:**
- White background, subtle shadow, rounded-xl
- Hover: lift effect (translate-y-1)

**Video Embeds:**
- 16:9 aspect ratio containers
- Rounded corners, shadow
- Placeholder with play button overlay

**Images:**
- All rounded-lg or rounded-xl
- Consistent aspect ratios within sections
- High-quality property/inspection imagery

## Images Required

1. **Hero**: Wide-angle shot of professional inspector examining home exterior/roof (bright, trust-inspiring)
2. **Services cards**: Close-ups of different inspection scenarios
3. **Process section**: Inspector with thermal camera, writing notes, reviewing with clients
4. **Why Choose**: Professional headshot or team photo with branded vehicle
5. **Gallery**: 12-15 varied inspection photos showing thoroughness
6. **CTA background**: Beautiful home exterior at golden hour
7. **Testimonial avatars**: Client photos (use placeholder if needed)

## Accessibility & Polish
- Consistent dark text on light backgrounds
- Sufficient contrast ratios (WCAG AA)
- Clear focus states
- Responsive images with proper loading
- Mobile-first responsive grid (stack to single column on mobile)
- Smooth scroll behavior between sections