import ContactForm from "./ContactForm";
import { Phone, Mail, MapPin, Clock } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function Contact() {
  return (
    <section id="contact" className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Schedule Your Inspection
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Get started with a professional home inspection. Fill out the form below and we'll contact you within 24 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          <div className="lg:col-span-2">
            <ContactForm />
          </div>

          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="font-bold text-lg mb-4 text-card-foreground">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 flex-shrink-0">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-card-foreground">Phone</p>
                    <a
                      href="tel:+17706483515"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      (770) 648-3515
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 flex-shrink-0">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-card-foreground">Email</p>
                    <a
                      href="mailto:torrey@troosec.com"
                      className="text-sm text-muted-foreground hover:text-primary transition-colors break-all"
                    >
                      torrey@troosec.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 flex-shrink-0">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-card-foreground">Service Area</p>
                    <p className="text-sm text-muted-foreground">
                      Greater Atlanta Metropolitan Area
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10 flex-shrink-0">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-card-foreground">Office Hours</p>
                    <p className="text-sm text-muted-foreground">Mon-Sat: 8am - 6pm</p>
                    <p className="text-sm text-muted-foreground">Sun: By Appointment</p>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="p-6 bg-chart-2/10 border-chart-2/20">
              <h3 className="font-bold text-lg mb-2 text-card-foreground">
                Same-Day Availability
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                In many cases, we can accommodate same-day or next-day inspections. Call us to check availability.
              </p>
              <a
                href="tel:+17706483515"
                className="inline-flex items-center gap-2 text-primary font-medium text-sm hover:underline"
              >
                <Phone className="h-4 w-4" />
                Call for Rush Service
              </a>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
