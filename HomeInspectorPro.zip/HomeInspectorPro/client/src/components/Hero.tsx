import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Award, Clock } from "lucide-react";

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url('/hero-background.png')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          opacity: 0.55
        }}
      />
      
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background/30 to-background/50" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32 text-center">
        <div className="max-w-4xl mx-auto space-y-6 lg:space-y-8">
          <div className="flex justify-center mb-8">
            <img 
              src="/troosec-logo.png" 
              alt="Troosec Inspections Logo" 
              className="h-24 w-24 lg:h-32 lg:w-32 object-contain"
            />
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-foreground leading-tight">
            Professional Home Inspections You Can Trust
          </h1>
          
          <p className="text-lg sm:text-xl lg:text-2xl text-muted-foreground font-medium">
            Comprehensive 24-Hour Reports • Certified • Serving Your Area
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button
              size="lg"
              className="text-base sm:text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-shadow"
              onClick={() => scrollToSection("contact")}
              data-testid="button-schedule-hero"
            >
              Schedule Inspection
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-base sm:text-lg px-8 py-6 bg-background/50 backdrop-blur-sm"
              onClick={() => scrollToSection("report-showcase")}
              data-testid="button-view-sample"
            >
              View Sample Report
            </Button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 lg:gap-8 pt-8">
            <div className="flex items-center gap-2 text-sm lg:text-base">
              <CheckCircle2 className="h-5 w-5 text-chart-2" />
              <span className="font-medium text-foreground">15+ Years Experience</span>
            </div>
            <div className="flex items-center gap-2 text-sm lg:text-base">
              <Award className="h-5 w-5 text-chart-2" />
              <span className="font-medium text-foreground">5000+ Inspections</span>
            </div>
            <div className="flex items-center gap-2 text-sm lg:text-base">
              <Clock className="h-5 w-5 text-chart-2" />
              <span className="font-medium text-foreground">24-Hour Reports</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
