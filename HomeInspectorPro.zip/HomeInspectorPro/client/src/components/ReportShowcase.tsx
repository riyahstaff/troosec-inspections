import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Camera, AlertTriangle, CheckCircle2, Clock, Shield } from "lucide-react";

const reportFeatures = [
  {
    icon: FileText,
    title: "200+ Inspection Points",
    description: "Every critical system and component thoroughly evaluated"
  },
  {
    icon: Camera,
    title: "High-Resolution Photos",
    description: "Clear images of all findings with detailed annotations"
  },
  {
    icon: AlertTriangle,
    title: "Priority Ratings",
    description: "Issues categorized by urgency and importance"
  },
  {
    icon: CheckCircle2,
    title: "Maintenance Recommendations",
    description: "Expert guidance for keeping your home in top condition"
  }
];

export default function ReportShowcase() {
  return (
    <section id="report-showcase" className="py-16 lg:py-24 bg-accent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <Badge className="mb-4 bg-chart-2 text-white hover:bg-chart-2/90">
            <Clock className="h-3 w-3 mr-1" />
            Delivered Within 24 Hours
          </Badge>
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Comprehensive Inspection Reports
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Detailed, easy-to-understand reports that give you complete confidence
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center mb-12">
          <Card className="p-8 lg:p-12 bg-card order-2 lg:order-1">
            <div className="aspect-[3/4] rounded-lg bg-muted relative overflow-hidden shadow-inner">
              <div className="absolute inset-0 bg-gradient-to-br from-background via-muted to-background p-6 lg:p-8">
                <div className="h-full flex flex-col">
                  <div className="flex items-center gap-3 mb-6">
                    <Shield className="h-8 w-8 text-primary" />
                    <div>
                      <h3 className="font-bold text-foreground">Troosec Inspections</h3>
                      <p className="text-xs text-muted-foreground">Professional Home Inspection Report</p>
                    </div>
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="bg-background rounded-lg p-4 shadow-sm">
                      <p className="text-xs text-muted-foreground mb-1">Property Address</p>
                      <p className="font-semibold text-sm">123 Main Street, Your City</p>
                    </div>
                    <div className="bg-background rounded-lg p-4 shadow-sm">
                      <p className="text-xs text-muted-foreground mb-1">Inspection Date</p>
                      <p className="font-semibold text-sm">October 20, 2025</p>
                    </div>
                  </div>

                  <div className="bg-background rounded-lg p-4 shadow-sm flex-1">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs">Structural Systems</span>
                        <Badge variant="outline" className="text-xs">Inspected</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs">Electrical Systems</span>
                        <Badge variant="outline" className="text-xs">Inspected</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs">Plumbing Systems</span>
                        <Badge variant="outline" className="text-xs">Inspected</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs">HVAC Systems</span>
                        <Badge variant="outline" className="text-xs">Inspected</Badge>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 text-center">
                    <p className="text-xs text-muted-foreground">200+ Points Inspected</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <div className="space-y-6 order-1 lg:order-2">
            {reportFeatures.map((feature, index) => (
              <Card
                key={index}
                className="p-6 hover:shadow-md transition-shadow"
                data-testid={`card-report-feature-${index}`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 flex-shrink-0">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-card-foreground mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        <Card className="p-8 bg-chart-2 text-white text-center">
          <Clock className="h-12 w-12 mx-auto mb-4 opacity-90" />
          <h3 className="text-2xl font-bold mb-2">24-Hour Report Guarantee</h3>
          <p className="text-white/90 max-w-2xl mx-auto">
            We understand timing is crucial in real estate transactions. That's why we guarantee delivery of your comprehensive inspection report within 24 hours of completion.
          </p>
        </Card>
      </div>
    </section>
  );
}