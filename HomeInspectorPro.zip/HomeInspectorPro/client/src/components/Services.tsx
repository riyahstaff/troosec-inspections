import { Card } from "@/components/ui/card";
import { Home, FileCheck, Building2, CheckCircle2 } from "lucide-react";

const services = [
  {
    icon: Home,
    title: "Pre-Purchase Inspections",
    description: "Comprehensive evaluation of your potential new home before you buy.",
    features: [
      "Structural integrity assessment",
      "Electrical & plumbing systems",
      "HVAC evaluation",
      "Roof and foundation inspection",
      "Pest and moisture detection"
    ]
  },
  {
    icon: FileCheck,
    title: "Pre-Listing Inspections",
    description: "Identify and address issues before listing your property for sale.",
    features: [
      "Detailed property condition report",
      "Repair recommendations",
      "Increase buyer confidence",
      "Faster closing process",
      "Better negotiating position"
    ]
  },
  {
    icon: Building2,
    title: "New Construction Inspections",
    description: "Ensure your new home meets quality standards and building codes.",
    features: [
      "Phase-by-phase inspection",
      "Code compliance verification",
      "Quality control assessment",
      "Builder accountability",
      "Final walkthrough support"
    ]
  }
];

export default function Services() {
  return (
    <section id="services" className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Professional inspection services tailored to your needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="p-6 lg:p-8 hover:-translate-y-1 transition-transform duration-300"
              data-testid={`card-service-${index}`}
            >
              <div className="flex items-center justify-center w-16 h-16 lg:w-20 lg:h-20 rounded-xl bg-primary/10 mb-6">
                <service.icon className="h-8 w-8 lg:h-10 lg:w-10 text-primary" />
              </div>
              
              <h3 className="text-xl lg:text-2xl font-bold text-card-foreground mb-4">
                {service.title}
              </h3>
              
              <p className="text-muted-foreground mb-6">
                {service.description}
              </p>

              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-chart-2 mt-0.5 flex-shrink-0" />
                    <span className="text-card-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
