import { Home, Shield, BookOpen, Images, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-background/95 backdrop-blur-sm shadow-sm" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <div className="flex items-center gap-2">
            <img 
              src="/troosec-logo.png" 
              alt="Troosec Inspections Logo" 
              className="h-10 w-10 lg:h-12 lg:w-12 object-contain"
            />
            <span className="text-xl lg:text-2xl font-bold text-foreground">
              Troosec Inspections
            </span>
          </div>

          <div className="hidden md:flex items-center gap-2 lg:gap-4">
            <Button
              variant="ghost"
              onClick={() => scrollToSection("services")}
              className="text-sm lg:text-base"
              data-testid="link-services"
            >
              Services
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection("process")}
              className="text-sm lg:text-base"
              data-testid="link-process"
            >
              Process
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection("gallery")}
              className="text-sm lg:text-base"
              data-testid="link-gallery"
            >
              Gallery
            </Button>
            <Button
              variant="ghost"
              onClick={() => scrollToSection("faq")}
              className="text-sm lg:text-base"
              data-testid="link-faq"
            >
              FAQ
            </Button>
            <Button
              onClick={() => scrollToSection("contact")}
              className="text-sm lg:text-base"
              data-testid="button-schedule"
            >
              Schedule Inspection
            </Button>
          </div>

          <Button
            onClick={() => scrollToSection("contact")}
            className="md:hidden"
            size="sm"
            data-testid="button-schedule-mobile"
          >
            Schedule
          </Button>
        </div>
      </div>
    </nav>
  );
}
