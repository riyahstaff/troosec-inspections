import { Card } from "@/components/ui/card";
import { Calendar, ClipboardCheck, FileText, Phone } from "lucide-react";
import InspectionVideo from "./InspectionVideo";

const steps = [
  {
    icon: Calendar,
    number: "01",
    title: "Schedule & Preparation",
    description: "Contact us to schedule your inspection. We'll provide a checklist of items to prepare and answer any questions.",
    duration: "5 minutes"
  },
  {
    icon: ClipboardCheck,
    number: "02",
    title: "On-Site Inspection",
    description: "Our certified inspector thoroughly examines your property, from foundation to roof, using advanced equipment and technology.",
    duration: "3-4 hours"
  },
  {
    icon: FileText,
    number: "03",
    title: "Detailed Report Delivery",
    description: "Receive a comprehensive inspection report with high-resolution photos, detailed descriptions, and priority ratings.",
    duration: "Within 24 hours",
    highlight: true
  },
  {
    icon: Phone,
    number: "04",
    title: "Follow-up Consultation",
    description: "We're available to discuss findings, answer questions, and provide recommendations for any issues discovered.",
    duration: "Unlimited support"
  }
];

export default function Process() {
  return (
    <section id="process" className="py-16 lg:py-24 bg-accent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            What to Expect
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Our streamlined inspection process ensures thoroughness and efficiency
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {steps.map((step, index) => (
            <Card
              key={index}
              className={`p-6 lg:p-8 relative ${
                step.highlight ? "ring-2 ring-chart-2 shadow-lg" : ""
              }`}
              data-testid={`card-process-${index}`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10">
                  <step.icon className="h-6 w-6 text-primary" />
                </div>
                <span className="text-4xl font-bold text-muted opacity-20">
                  {step.number}
                </span>
              </div>

              {step.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-chart-2 text-white text-xs font-semibold px-3 py-1 rounded-full">
                    24-Hour Guarantee
                  </span>
                </div>
              )}

              <h3 className="text-xl lg:text-2xl font-bold text-card-foreground mb-2">
                {step.title}
              </h3>

              <p className="text-sm text-primary font-medium mb-4">
                {step.duration}
              </p>

              <p className="text-muted-foreground text-sm">
                {step.description}
              </p>
            </Card>
          ))}
        </div>

        <div className="mt-12 lg:mt-16">
          <InspectionVideo 
            title="Watch: Inside a Troosec Home Inspection"
            description="See our thorough inspection process in action"
          />
        </div>
      </div>
    </section>
  );
}
