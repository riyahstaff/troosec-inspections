import { Card } from "@/components/ui/card";
import { Home, Wrench, Zap, Droplet, Wind, Shield } from "lucide-react";

const galleryItems = [
  {
    icon: Home,
    title: "Structural Inspection",
    category: "Foundation & Framing"
  },
  {
    icon: Zap,
    title: "Electrical Systems",
    category: "Safety & Compliance"
  },
  {
    icon: Droplet,
    title: "Plumbing Assessment",
    category: "Water & Drainage"
  },
  {
    icon: Wind,
    title: "HVAC Evaluation",
    category: "Heating & Cooling"
  },
  {
    icon: Wrench,
    title: "Appliance Testing",
    category: "Built-in Systems"
  },
  {
    icon: Shield,
    title: "Roof Inspection",
    category: "Exterior Protection"
  },
  {
    icon: Home,
    title: "Interior Details",
    category: "Living Spaces"
  },
  {
    icon: Droplet,
    title: "Moisture Detection",
    category: "Advanced Technology"
  }
];

export default function Gallery() {
  return (
    <section id="gallery" className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Our Work in Action
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            See the thoroughness and attention to detail we bring to every inspection
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {galleryItems.map((item, index) => (
            <Card
              key={index}
              className="group overflow-hidden hover:-translate-y-1 transition-all duration-300 cursor-pointer"
              data-testid={`card-gallery-${index}`}
            >
              <div className="aspect-[4/3] bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <item.icon className="h-16 w-16 text-primary group-hover:scale-110 transition-transform" />
              </div>
              <div className="p-4">
                <h3 className="font-bold text-card-foreground mb-1">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.category}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
