import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    initials: "SJ",
    propertyType: "Single Family Home",
    date: "September 2025",
    rating: 5,
    quote: "Troosec Inspections was incredibly thorough and professional. The report was detailed and helped us make an informed decision about our purchase. Highly recommend!"
  },
  {
    name: "Michael Chen",
    initials: "MC",
    propertyType: "Condominium",
    date: "August 2025",
    rating: 5,
    quote: "The 24-hour report turnaround was crucial for our tight timeline. The inspector was knowledgeable and took time to explain everything. Excellent service!"
  },
  {
    name: "Emily Rodriguez",
    initials: "ER",
    propertyType: "New Construction",
    date: "October 2025",
    rating: 5,
    quote: "We used Troosec for our new construction inspection and couldn't be happier. They caught several issues before closing that saved us thousands. True professionals!"
  }
];

export default function Testimonials() {
  return (
    <section className="py-16 lg:py-24 bg-accent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            What Our Clients Say
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Join hundreds of satisfied homeowners who trusted us with their inspection
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="p-6 lg:p-8 flex flex-col"
              data-testid={`card-testimonial-${index}`}
            >
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>

              <p className="text-card-foreground mb-6 flex-1 italic">
                "{testimonial.quote}"
              </p>

              <div className="flex items-center gap-3 pt-4 border-t">
                <Avatar>
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-card-foreground">{testimonial.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.propertyType} • {testimonial.date}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
