import { Card } from "@/components/ui/card";
import { CheckCircle2, Shield, Clock, Camera, FileText, HeadphonesIcon } from "lucide-react";

const benefits = [
  {
    icon: Shield,
    title: "Certified",
    description: "Fully insured professionals with ongoing training"
  },
  {
    icon: Clock,
    title: "24-Hour Report Delivery",
    description: "Comprehensive reports delivered within 24 hours, guaranteed"
  },
  {
    icon: Camera,
    title: "High-Quality Documentation",
    description: "Detailed photos and videos of all findings and concerns"
  },
  {
    icon: FileText,
    title: "200+ Inspection Points",
    description: "Thorough evaluation covering every critical system and component"
  },
  {
    icon: HeadphonesIcon,
    title: "Ongoing Support",
    description: "Available for questions even after your inspection is complete"
  }
];

export default function WhyChoose() {
  return (
    <section className="py-16 lg:py-24 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Why Choose Troosec Inspections
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto">
            Experience the difference of working with dedicated professionals
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div className="space-y-4">
            {benefits.map((benefit, index) => (
              <Card
                key={index}
                className="p-6 hover:shadow-md transition-shadow"
                data-testid={`card-benefit-${index}`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-primary/10 flex-shrink-0">
                    <benefit.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-card-foreground mb-1">
                      {benefit.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          <div className="relative">
            <Card className="p-8 bg-gradient-to-br from-primary/5 to-primary/10">
              <div className="aspect-[4/3] rounded-lg bg-muted flex items-center justify-center overflow-hidden relative">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10" />
                <div className="relative text-center p-8">
                  <Shield className="h-24 w-24 text-primary mx-auto mb-4 opacity-80" />
                  <p className="text-lg font-semibold text-foreground mb-2">
                    Professional Equipment & Expertise
                  </p>
                  <p className="text-sm text-muted-foreground">
                    State-of-the-art tools including thermal imaging, moisture meters, and digital reporting systems
                  </p>
                </div>
              </div>
            </Card>

            <div className="absolute -bottom-6 -right-6 w-48 h-48 bg-chart-2/10 rounded-full blur-3xl -z-10" />
            <div className="absolute -top-6 -left-6 w-48 h-48 bg-primary/10 rounded-full blur-3xl -z-10" />
          </div>
        </div>
      </div>
    </section>
  );
}
