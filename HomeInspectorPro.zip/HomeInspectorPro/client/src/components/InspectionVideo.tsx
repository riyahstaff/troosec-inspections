
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Play } from "lucide-react";

interface InspectionVideoProps {
  title?: string;
  description?: string;
  videoUrl?: string;
  thumbnailUrl?: string;
}

export default function InspectionVideo({
  title = "Inside a Troosec Home Inspection",
  description = "See our thorough inspection process in action",
  videoUrl = "https://youtube.com/shorts/IwU4JnYhHoI?si=bVSPu5a72Q7Vxewg",
  thumbnailUrl
}: InspectionVideoProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handlePlayClick = () => {
    setIsOpen(true);
  };

  // Extract video ID from YouTube URL if needed
  const getEmbedUrl = (url: string) => {
    if (url.includes('youtube.com/embed/')) {
      return url;
    }
    if (url.includes('youtube.com/watch?v=')) {
      const videoId = url.split('v=')[1]?.split('&')[0];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    if (url.includes('youtu.be/')) {
      const videoId = url.split('youtu.be/')[1]?.split('?')[0];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    if (url.includes('youtube.com/shorts/')) {
      const videoId = url.split('shorts/')[1]?.split('?')[0];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    return url;
  };

  return (
    <>
      <Card className="p-6 lg:p-8 bg-card">
        <div 
          className="aspect-video rounded-lg bg-muted flex items-center justify-center relative overflow-hidden group cursor-pointer" 
          onClick={handlePlayClick}
        >
          {thumbnailUrl ? (
            <>
              <img 
                src={thumbnailUrl} 
                alt={title}
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors" />
            </>
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5" />
          )}
          
          <div className="relative text-center z-10">
            <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mb-4 mx-auto shadow-xl group-hover:scale-110 transition-transform">
              <Play className="w-10 h-10 text-primary-foreground ml-1" fill="currentColor" />
            </div>
            <p className="text-lg font-semibold text-white drop-shadow-lg">
              {title}
            </p>
            <p className="text-sm text-white/90 mt-2 drop-shadow-md">
              {description}
            </p>
          </div>
        </div>
      </Card>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl w-full p-0">
          <div className="aspect-video w-full">
            <iframe
              src={getEmbedUrl(videoUrl)}
              title={title}
              className="w-full h-full rounded-lg"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
