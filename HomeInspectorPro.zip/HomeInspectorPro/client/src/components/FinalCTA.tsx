import { Button } from "@/components/ui/button";
import { Phone, Mail } from "lucide-react";

export default function FinalCTA() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="py-16 lg:py-24 bg-gradient-to-br from-primary to-primary/80 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white/10 via-transparent to-transparent" />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
        <h2 className="text-3xl lg:text-5xl font-bold mb-4 lg:mb-6">
          Ready for Peace of Mind?
        </h2>
        <p className="text-lg lg:text-xl mb-8 lg:mb-12 text-white/90">
          Schedule your professional home inspection today and receive your comprehensive report within 24 hours.
        </p>

        <Button
          size="lg"
          variant="outline"
          className="text-base lg:text-lg px-8 py-6 bg-white text-primary border-white hover:bg-white/90 shadow-xl mb-8"
          onClick={() => scrollToSection("contact")}
          data-testid="button-schedule-cta"
        >
          Schedule Your Inspection
        </Button>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 lg:gap-8 pt-8 border-t border-white/20">
          <a
            href="tel:+17706483515"
            className="flex items-center gap-2 text-white hover:text-white/90 transition-colors"
            data-testid="link-phone"
          >
            <Phone className="h-5 w-5" />
            <span className="font-medium">(770) 648-3515</span>
          </a>
          <a
            href="mailto:torrey@troosec.com"
            className="flex items-center gap-2 text-white hover:text-white/90 transition-colors"
            data-testid="link-email"
          >
            <Mail className="h-5 w-5" />
            <span className="font-medium">torrey@troosec.com</span>
          </a>
        </div>
      </div>
    </section>
  );
}
