import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How long does a home inspection take?",
    answer: "A typical home inspection takes 3-4 hours depending on the size and condition of the property. We thoroughly examine all accessible areas including the roof, foundation, electrical, plumbing, HVAC, and interior spaces."
  },
  {
    question: "When will I receive my inspection report?",
    answer: "We guarantee delivery of your comprehensive inspection report within 24 hours of completing the inspection. The report includes high-resolution photos, detailed descriptions, and priority ratings for any issues found."
  },
  {
    question: "Can I attend the inspection?",
    answer: "Absolutely! We encourage buyers to attend the inspection. This gives you the opportunity to ask questions, see issues firsthand, and better understand your potential new home. We'll take time to explain our findings as we go."
  },
  {
    question: "What does a home inspection cover?",
    answer: "Our comprehensive inspection covers over 200 points including: structural components, roof and attic, exterior, electrical system, plumbing, HVAC, interior, insulation and ventilation, and built-in appliances. We use thermal imaging and moisture detection equipment when needed."
  },
  {
    question: "How much does a home inspection cost?",
    answer: "Inspection costs vary based on property size, age, and type. Contact us for a detailed quote. We believe in transparent pricing with no hidden fees, and our comprehensive reports provide exceptional value for your investment."
  },
  {
    question: "What if issues are found during the inspection?",
    answer: "If we find issues, they'll be clearly documented in your report with photos, descriptions, and priority ratings. We categorize findings as safety concerns, major defects, or maintenance items. You can use this information to negotiate repairs or pricing with the seller."
  },
  {
    question: "Are you certified and insured?",
    answer: "Yes, we are fully certified and insured. Our inspectors maintain ongoing education and certifications to stay current with building codes and industry best practices."
  },
  {
    question: "Do you inspect new construction homes?",
    answer: "Yes! New construction inspections are crucial. We offer phase-by-phase inspections during construction and a final walkthrough before closing. Even new homes can have quality control issues that should be addressed before you take ownership."
  }
];

export default function FAQ() {
  return (
    <section id="faq" className="py-16 lg:py-24 bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl lg:text-5xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg lg:text-xl text-muted-foreground">
            Everything you need to know about our inspection services
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="bg-card rounded-lg px-6 border-card-border"
              data-testid={`accordion-faq-${index}`}
            >
              <AccordionTrigger className="text-left hover:no-underline">
                <span className="font-semibold text-card-foreground pr-4">
                  {faq.question}
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}
