import { Shield, Phone, Mail, MapPin, Facebook } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-foreground text-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <img 
                src="/troosec-logo.png" 
                alt="Troosec Inspections Logo" 
                className="h-8 w-8 object-contain brightness-0 invert"
              />
              <span className="text-xl font-bold">Troosec Inspections</span>
            </div>
            <p className="text-background/80 text-sm mb-4">
              Professional home inspection services with comprehensive 24-hour reports. Certified and trusted by homeowners.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => scrollToSection("services")}
                  className="text-background/80 hover:text-background transition-colors"
                  data-testid="footer-link-services"
                >
                  Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("process")}
                  className="text-background/80 hover:text-background transition-colors"
                  data-testid="footer-link-process"
                >
                  Our Process
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("gallery")}
                  className="text-background/80 hover:text-background transition-colors"
                  data-testid="footer-link-gallery"
                >
                  Gallery
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("faq")}
                  className="text-background/80 hover:text-background transition-colors"
                  data-testid="footer-link-faq"
                >
                  FAQ
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Contact Info</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <a href="tel:+17706483515" className="text-background/80 hover:text-background transition-colors">
                  (770) 648-3515
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <a
                  href="mailto:torrey@troosec.com"
                  className="text-background/80 hover:text-background transition-colors"
                >
                  torrey@troosec.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span className="text-background/80">
                  Serving the Greater Atlanta Metropolitan Area
                </span>
              </li>
            </ul>
            <div className="mt-4">
              <p className="text-xs text-background/60 mb-1">Office Hours:</p>
              <p className="text-sm text-background/80">Monday - Saturday: 8am - 6pm</p>
              <p className="text-sm text-background/80">Sunday: By Appointment</p>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Newsletter</h3>
            <p className="text-sm text-background/80 mb-4">
              Subscribe for home maintenance tips and inspection insights.
            </p>
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="Your email"
                className="bg-background/10 border-background/20 text-background placeholder:text-background/50"
                data-testid="input-newsletter"
              />
              <Button variant="outline" className="bg-background text-foreground hover:bg-background/90" data-testid="button-subscribe">
                Subscribe
              </Button>
            </div>
            <div className="mt-6">
              <p className="text-xs text-background/60 mb-2">Certifications:</p>
              <p className="text-sm text-background/80">Certified & Insured</p>
              <p className="text-sm text-background/80">InterNACHI Certified</p>
            </div>
          </div>
        </div>

        <div className="border-t border-background/20 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-background/60">
          <p>© 2025 Troosec Inspections. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#" className="hover:text-background transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-background transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}