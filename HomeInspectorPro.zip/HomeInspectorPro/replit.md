# Troosec Inspections - Home Inspection Website

## Overview
A modern, professional website for Troosec Inspections, a home inspection business. The website showcases services, educates clients about home inspections, features photo and video galleries, and highlights the company's 24-hour report delivery guarantee.

## Project Goals
- Create a visually stunning, professional website that builds trust
- Educate potential clients about the home inspection process
- Showcase services and expertise through compelling content
- Provide easy scheduling through a contact form
- Highlight the 24-hour report delivery guarantee

## Current State
**Phase:** MVP Complete - All frontend components built
**Status:** Frontend implementation finished, backend in progress

## Recent Changes (October 21, 2025)
- Initialized project with full-stack JavaScript template
- Designed comprehensive schema for contact form submissions
- Implemented complete frontend with all major sections:
  - Navigation with smooth scrolling
  - Hero section with gradient backgrounds
  - Services overview (3 inspection types)
  - Process timeline (4-step inspection process)
  - Why Choose section with benefits
  - Report showcase highlighting 24-hour delivery
  - Gallery of inspection work
  - Testimonials from clients
  - FAQ accordion
  - Final CTA section
  - Contact form with validation
  - Rich footer with links and newsletter signup
- Configured Inter font and design tokens following design guidelines
- Added SEO meta tags and Open Graph support

## Project Architecture

### Frontend Stack
- **Framework:** React with TypeScript
- **Routing:** Wouter
- **Styling:** Tailwind CSS with Shadcn UI components
- **Forms:** React Hook Form with Zod validation
- **State Management:** TanStack Query
- **Font:** Inter (400, 500, 600, 700 weights)

### Backend Stack
- **Server:** Express.js
- **Storage:** In-memory storage (MemStorage)
- **Validation:** Zod schemas from drizzle-zod

### Design System
**Color Palette:**
- Primary: Professional blue (210 85% 45%)
- Success: Green for 24-hour guarantee messaging (145 65% 45%)
- Background: Clean white (0 0% 98%)
- Foreground: Navy-charcoal for text (220 15% 15%)
- Accent: Light blue for section backgrounds (210 40% 96%)

**Typography:**
- Font Family: Inter
- Headings: 700, 600 weights
- Body: 400, 500 weights
- Hero H1: text-5xl lg:text-7xl
- Section H2: text-3xl lg:text-5xl
- Card H3: text-xl lg:text-2xl

**Spacing:**
- Section padding: py-16 lg:py-24
- Card padding: p-6 lg:p-8
- Grid gaps: gap-6 lg:gap-8

### Key Features
1. **Hero Section:** Full-width gradient background with dual CTAs and trust badges
2. **Services:** 3-column grid showcasing inspection types with feature lists
3. **Process Timeline:** 4-step visual guide with 24-hour guarantee highlight
4. **Why Choose:** 2-column layout with benefits and visual element
5. **Report Showcase:** Sample report preview with feature callouts
6. **Gallery:** Grid of inspection work categories
7. **Testimonials:** Client reviews with ratings
8. **FAQ:** Accordion with 8 common questions
9. **Contact Form:** Full-featured scheduling form with validation
10. **Responsive Design:** Mobile-first approach with breakpoints

### Page Structure
```
/
├── Navigation (fixed, scrollable sections)
├── Hero
├── Services
├── Process
├── Why Choose
├── Report Showcase
├── Gallery
├── Testimonials
├── FAQ
├── Final CTA
├── Contact
└── Footer
```

### Data Models

#### Contact Submission
```typescript
{
  id: string (uuid, auto-generated)
  name: string (required)
  email: string (required, validated)
  phone: string (required, min 10 chars)
  propertyAddress: string (required)
  inspectionType: string (required, pre-purchase|pre-listing|new-construction|other)
  preferredDate: string (optional)
  message: string (optional)
  createdAt: timestamp (auto-generated)
}
```

## Component Organization
- **Pages:** `/client/src/pages/Home.tsx`
- **Components:** `/client/src/components/`
  - Navigation.tsx
  - Hero.tsx
  - Services.tsx
  - Process.tsx
  - WhyChoose.tsx
  - ReportShowcase.tsx
  - Gallery.tsx
  - Testimonials.tsx
  - FAQ.tsx
  - FinalCTA.tsx
  - Contact.tsx
  - ContactForm.tsx
  - Footer.tsx

## API Endpoints (Planned)
- `POST /api/contact` - Submit contact form for inspection scheduling

## Environment Configuration
- No external API keys required for MVP
- In-memory storage for contact submissions

## Development Workflow
1. Start dev server: `npm run dev` (runs Express + Vite)
2. Frontend served on port 5000
3. Backend API routes prefixed with `/api`
4. Hot reload enabled for both frontend and backend

## Next Steps
- [ ] Implement backend API endpoint for contact form
- [ ] Connect frontend to backend
- [ ] Add error handling and loading states
- [ ] Test complete user journey
- [ ] Deploy to production

## Design Philosophy
Following premium service website patterns (Airbnb's trust-building, Apple's professionalism) with emphasis on:
- Clean, modern aesthetic
- Professional trust signals
- Educational content that converts
- Smooth user experience
- Mobile-first responsive design
